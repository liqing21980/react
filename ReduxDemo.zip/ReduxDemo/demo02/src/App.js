import React from 'react'
import TodoList from './todolist'


export default class App extends React.Component {
  render() {
    return (
      <div>
        <TodoList />
      </div>
    )
  }
}

